import tempfile
import unittest
from translation_lab import DurableTranslationCache, TranslationRejected


class TestDurableCache(unittest.TestCase):
    def test_persistence_after_restarting_the_process(self):
        with tempfile.TemporaryDirectory() as folder:
            original = "学校"
            with DurableTranslationCache(folder) as first:
                result = first.translate_or_get("ja", "es", original, lambda _: "escuela")
                self.assertEqual(result, "escuela")
                self.assertEqual(first.count(), 1)
            def must_not_translate(_):
                raise AssertionError("Repeated translation called the model again")
            with DurableTranslationCache(folder) as second:
                cached = second.translate_or_get("ja", "es", original, must_not_translate)
                self.assertEqual(cached, "escuela")
                self.assertEqual(second.count(), 1)

    def test_empty_translation_never_enters_storage(self):
        with tempfile.TemporaryDirectory() as folder:
            with DurableTranslationCache(folder) as cache:
                with self.assertRaises(TranslationRejected):
                    cache.put("ja", "es", "学校", "")
                self.assertEqual(cache.count(), 0)

    def test_failed_neural_attempt_not_cached(self):
        with tempfile.TemporaryDirectory() as folder:
            with DurableTranslationCache(folder) as cache:
                with self.assertRaises(TranslationRejected):
                    cache.translate_or_get("ja", "es", "学校", lambda x: x)
                self.assertEqual(cache.count(), 0)

    def test_model_failure_is_not_cached(self):
        with tempfile.TemporaryDirectory() as folder:
            with DurableTranslationCache(folder) as cache:
                def failed(_):
                    raise RuntimeError("MODEL_UNAVAILABLE")
                with self.assertRaises(RuntimeError):
                    cache.translate_or_get("ja", "es", "学校", failed)
                self.assertEqual(cache.count(), 0)

    def test_cache_key_includes_original_source_and_target(self):
        with tempfile.TemporaryDirectory() as folder:
            with DurableTranslationCache(folder) as cache:
                cache.put("ja", "es", "学校", "escuela")
                self.assertIsNone(cache.get("en", "es", "学校"))
                self.assertIsNone(cache.get("ja", "en", "学校"))
                self.assertIsNone(cache.get("ja", "es", "校門"))

    def test_corrected_translation_replaces_existing_row(self):
        with tempfile.TemporaryDirectory() as folder:
            with DurableTranslationCache(folder) as cache:
                cache.put("ja", "es", "学校", "escuela")
                cache.put("ja", "es", "学校", "colegio")
                self.assertEqual(cache.count(), 1)
                self.assertEqual(cache.get("ja", "es", "学校"), "colegio")

    def test_unicode_and_punctuation_survive_restart(self):
        with tempfile.TemporaryDirectory() as folder:
            original = "「学校はどこですか？」"
            expected = "«¿Dónde está la escuela?»"
            with DurableTranslationCache(folder) as cache:
                cache.put("ja", "es", original, expected)
            with DurableTranslationCache(folder) as cache:
                self.assertEqual(cache.get("ja", "es", original), expected)

    def test_damaged_cached_translation_is_not_reused(self):
        with tempfile.TemporaryDirectory() as folder:
            with DurableTranslationCache(folder) as cache:
                cache.put("ja", "es", "学校", "escuela")
                with cache.connection:
                    cache.connection.execute(
                        "UPDATE translations SET translated=? WHERE original=?",
                        ("残った日本語", "学校")
                    )
                self.assertIsNone(cache.get("ja", "es", "学校"))
